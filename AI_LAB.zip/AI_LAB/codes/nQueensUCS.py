def is_safe(board, row, col, n):
    # Check if there is a queen in the same column or diagonal
    for r, c in enumerate(board):
        if c == col or \
           r - c == row - col or \
           r + c == row + col:
            return False
    return True

def solve_n_queens_ucs(n):
    solutions = []

    def ucs(board, row, cost_limit):
        if row == n:
            solutions.append(board[:])  # Make a copy of the board
            return True
        if cost_limit == 0:
            return False
        for col in range(n):
            if is_safe(board, row, col, n):
                board.append(col)
                if ucs(board, row + 1, cost_limit - row - 1):
                    return True
                board.pop()
        return False

    cost_limit = 1
    while not ucs([], 0, cost_limit):
        cost_limit += 1

    return solutions

def print_solutions(solutions):
    for i, solution in enumerate(solutions):
        print(f"Solution {i+1}:")
        for row in range(len(solution)):
            print(''.join(['Q' if solution[row] == col else '.' for col in range(len(solution))]))
        print()

if __name__ == "__main__":
    n = 8 
    solutions = solve_n_queens_ucs(n)
    print_solutions(solutions)
