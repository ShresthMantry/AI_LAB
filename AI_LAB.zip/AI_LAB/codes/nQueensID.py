def is_safe(board, row, col, n):
    # Check if there is a queen in the same column or diagonal
    for r, c in enumerate(board):
        if c == col or \
           r - c == row - col or \
           r + c == row + col:
            return False
    return True

def solve_n_queens_iddfs(n):
    solutions = []

    def dfs(board, row, depth_limit):
        if row == n:
            solutions.append(board[:])  # Make a copy of the board
            return True
        if depth_limit == 0:
            return False
        for col in range(n):
            if is_safe(board, row, col, n):
                board.append(col)
                if dfs(board, row + 1, depth_limit - 1):
                    return True
                board.pop()
        return False

    depth_limit = 1
    while not dfs([], 0, depth_limit):
        depth_limit += 1

    return solutions

def print_solutions(solutions):
    for i, solution in enumerate(solutions):
        print(f"Solution {i+1}:")
        for row in range(len(solution)):
            print(''.join(['Q' if solution[row] == col else '.' for col in range(len(solution))]))
        print()

if __name__ == "__main__":
    n = 8 
    solutions = solve_n_queens_iddfs(n)
    print_solutions(solutions)
