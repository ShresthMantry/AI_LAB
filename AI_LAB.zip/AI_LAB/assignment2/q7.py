import numpy as np

arr = np.array([[10, 16, 71, 9], [71, 91, 31, 51]])

print(f"Dimension of the array: {arr.ndim}")

print(f"Shape of the array: {arr.shape}")

print(f"Size of the array: {arr.size}")
