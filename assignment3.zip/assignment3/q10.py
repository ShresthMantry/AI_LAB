
scores = [85, 92, 75, 85, 90, 92, 85, 75, 85, 92, 75, 85, 90, 92, 85, 75, 85, 92]
frequency_85 = scores.count(85)

print("Frequency of the score 85:", frequency_85)
